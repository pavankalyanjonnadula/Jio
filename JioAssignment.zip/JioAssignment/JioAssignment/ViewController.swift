//
//  ViewController.swift
//  JioAssignment
//
//  Created by Pavan Kalyan Jonnadula on 20/08/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource{
    var arrUsers = [Users]()
    var usersTableView = UITableView()

    var dupliacteUsers = [Users]()
    let search = UISearchController(searchResultsController: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        initializeView()
        getAllUsers()
    }
    func initializeView(){
        usersTableView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        self.view.addSubview(usersTableView)
        usersTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        usersTableView.delegate = self
        usersTableView.dataSource = self
        addSearchBar()
    }

    func addSearchBar(){
        //For title in navigation bar
        self.navigationItem.title = "GitHub Users"
        search.searchResultsUpdater = self
        search.hidesNavigationBarDuringPresentation = false
        search.searchBar.sizeToFit()
        search.searchBar.barTintColor = UIColor.systemBackground
        search.searchBar.backgroundColor = UIColor.clear
        self.usersTableView.tableHeaderView = search.searchBar

    }
    func getAllUsers(){
        AF.request("https://api.github.com/users").response { response in
            if let data = response.data {
                do{
                    let userResponse = try JSONDecoder().decode([Users].self, from: data)
                    self.arrUsers.append(contentsOf: userResponse)
                    DispatchQueue.main.async{
                        self.usersTableView.reloadData()
                    }
                }catch let err{
                    print(err.localizedDescription)
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrUsers.count
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let usersCell = UserCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: "cell")
        usersCell.textLabel?.text = arrUsers[indexPath.row].login ?? ""
        usersCell.accessoryType = .disclosureIndicator
        usersCell.imageView?.sd_setImage(with: URL(string: arrUsers[indexPath.row].avatarUrl ?? ""), completed: { (image, error, type, url) in
            usersCell.imageView!.layer.cornerRadius = 18
            usersCell.imageView!.layer.masksToBounds = true
            usersCell.imageView!.image = image

        })
        return usersCell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = arrUsers[indexPath.row]
        let userDetailsVC = UserDetailsViewController()
        userDetailsVC.userName = user.login ?? ""
        self.navigationController?.pushViewController(userDetailsVC, animated: true)
    }
}

extension ViewController : UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        if let text = searchController.searchBar.text, !text.isEmpty {
            
        }
    }
   
}

class UserCell : UITableViewCell{
    override func layoutSubviews() {
        super.layoutSubviews()
        self.imageView?.frame = CGRect(x: 20, y: 4, width: 36, height: 36)
    }
}
