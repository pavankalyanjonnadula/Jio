//
//  UserDetailsViewController.swift
//  JioAssignment
//
//  Created by Pavan Kalyan Jonnadula on 22/08/20.
//  Copyright © 2020 Pavan Kalyan Jonnadula. All rights reserved.
//

import UIKit
import SDWebImage
import Alamofire

class UserDetailsViewController: UIViewController , UITableViewDelegate , UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
    
    var userName = String()
    var detailsTableView = UITableView(frame: .zero, style: .grouped)
    var userInfo : UserDetails?
    var sectionTwoDetails = ["Followers","Repositories","Blog","Github"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        detailsTableView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)

        self.view.addSubview(detailsTableView)
        detailsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")

        getUserDetails()
        detailsTableView.delegate = self
        detailsTableView.dataSource = self
    }
    func getUserDetails(){
        let url =  "https://api.github.com/users/\(userName)"
        AF.request(url).response { response in
            if let data = response.data {
                do{
                    let userResponse = try JSONDecoder().decode(UserDetails.self, from: data)
                    self.userInfo = userResponse
                    DispatchQueue.main.async {
                        self.detailsTableView.reloadData()
                    }
                }catch let DecodingError.dataCorrupted(context) {
                    print(context)
                } catch let DecodingError.keyNotFound(key, context) {
                    print("Key '\(key)' not found:", context.debugDescription)
                    print("codingPath:", context.codingPath)
                } catch let DecodingError.valueNotFound(value, context) {
                    print("Value '\(value)' not found:", context.debugDescription)
                    print("codingPath:", context.codingPath)
                } catch let DecodingError.typeMismatch(type, context)  {
                    print("Type '\(type)' mismatch:", context.debugDescription)
                    print("codingPath:", context.codingPath)
                } catch {
                    print("error: ", error)
                }
            }
        }
    }
    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let detailsCell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
//        if indexPath.section == 0 && indexPath.row == 0{
//            detailsCell.textLabel?.text = userInfo?.name ?? ""
//            detailsCell.detailTextLabel?.text = "Full Name"
//        }else if indexPath.section == 0 && indexPath.row == 1{
//            detailsCell.textLabel?.text = userInfo?.location ?? ""
//            detailsCell.detailTextLabel?.text = "Location"
//        }else if indexPath.section == 0 && indexPath.row == 2{
//            detailsCell.textLabel?.text = userInfo?.createdAt ?? ""
//            detailsCell.detailTextLabel?.text = "Created At"
//        }else if indexPath.section == 0 && indexPath.row == 3{
//            detailsCell.textLabel?.text = userInfo?.updatedAt ?? ""
//            detailsCell.detailTextLabel?.text = "Updated At"
//        }else if indexPath.section == 1{
//            detailsCell.textLabel?.text = sectionTwoDetails[indexPath.row]
//            detailsCell.accessoryType = .disclosureIndicator
//        }
//
//        return detailsCell
//    }
//
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return 2
//    }
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return 4
//    }
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        if section == 0{
//            return 200
//        }else{
//            return 30
//        }
//    }
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        if section == 1{
//            return "More Information"
//        }
//        return nil
//    }
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        if section == 0{
//            let userImage = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 200))
//            userImage.sd_setImage(with: URL(string: userInfo?.avatarUrl ?? ""), completed: nil)
//            return userImage
//        }
//        return nil
//
//    }
//
}
